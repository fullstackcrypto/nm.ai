# Placeholder for cloud sync plugin
