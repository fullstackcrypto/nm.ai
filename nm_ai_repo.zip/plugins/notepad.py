# Placeholder for notepad plugin
